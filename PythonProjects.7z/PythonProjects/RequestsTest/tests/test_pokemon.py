import requests

import pytest

host = 'https://pokemonbattle.me:9104/'

token = 'c0573dd951ea192fa7dd65c00d922ef1'

def test_status_code():

    trainer_info = requests.get(f'{host}trainers', params = {"trainer_id": 4624})

    assert trainer_info.status_code == 200

def test_trainers_name():

    answer_body = requests.get(f'{host}trainers', params = {"trainer_id": 4624})

    assert answer_body.json()['trainer_name'] == 'Артемий'
                               