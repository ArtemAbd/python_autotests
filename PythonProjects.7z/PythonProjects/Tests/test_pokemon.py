import requests

token = 'c0573dd951ea192fa7dd65c00d922ef1'

host = 'https://pokemonbattle.me:9104/'

trainer_info = requests.get(f'{host}trainers',
                            params = {"trainer_id": 4624})

print(trainer_info.text)